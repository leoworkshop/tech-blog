package com.leosoft.leosoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeosoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
